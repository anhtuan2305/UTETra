package vn.tuan.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
<<<<<<< HEAD
=======
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
<<<<<<< HEAD
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable()) // Tắt CSRF để tiện test các form POST
            .authorizeHttpRequests(auth -> auth
                // CÁC ĐƯỜNG DẪN CÔNG KHAI (Cho phép Guest và Chưa đăng nhập truy cập)
                .requestMatchers(
                    "/", 
                    "/home", 
                    "/register/**", 
                    "/verify-otp/**", 
                    "/forgot-password/**", 
                    "/reset-password/**", 
                    "/login", 
                    "/products/**", 
                    "/css/**", 
                    "/js/**", 
                    "/images/**", 
                    "/favicon.ico"
                ).permitAll()
                
                // CÁC ĐƯỜNG DẪN DÀNH CHO VENDOR (CHỦ QUÁN)
                .requestMatchers("/vendor/**").hasRole("VENDOR")
                
                // CÁC ĐƯỜNG DẪN DÀNH CHO ADMIN (QUẢN TRỊ VIÊN)
                .requestMatchers("/admin/**").hasRole("ADMIN")
             // CÁC ĐƯỜNG DẪN DÀNH CHO SHIPPER
                .requestMatchers("/shipper/**").hasRole("SHIPPER")
                
                // TẤT CẢ CÁC ĐƯỜNG DẪN CÒN LẠI PHẢI ĐĂNG NHẬP
=======
    public AuthenticationManager authenticationManager(AuthenticationConfiguration configuration) throws Exception {
        return configuration.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable()) // Tạm thời disable CSRF để dễ test form/API
            .authorizeHttpRequests(auth -> auth
                // Tài nguyên tĩnh không cần đăng nhập
                .requestMatchers("/css/**", "/js/**", "/images/**", "/webjars/**").permitAll()
                // Các trang công khai: Trang chủ, Sản phẩm, Đăng ký, Đăng nhập, Xác thực OTP
                .requestMatchers("/", "/home", "/products/**", "/register", "/verify-otp", "/login").permitAll()
                // Phân quyền theo Role
                .requestMatchers("/admin/**").hasRole("ADMIN")
                .requestMatchers("/manager/**").hasAnyRole("ADMIN", "MANAGER")
                .requestMatchers("/vendor/**").hasRole("VENDOR")
                .requestMatchers("/shipper/**").hasRole("SHIPPER")
                // Các tính năng mua sắm bắt buộc phải đăng nhập
                .requestMatchers("/cart/**", "/checkout/**", "/profile/**", "/orders/**").authenticated()
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login")
                .loginProcessingUrl("/login")
<<<<<<< HEAD
                .usernameParameter("username")
                .passwordParameter("password")
=======
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963
                .defaultSuccessUrl("/", true)
                .failureUrl("/login?error=true")
                .permitAll()
            )
            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/login?logout=true")
                .invalidateHttpSession(true)
                .deleteCookies("JSESSIONID")
                .permitAll()
            );

        return http.build();
    }
}