package vn.tuan.repository;

<<<<<<< HEAD
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.tuan.entity.Account;
import vn.tuan.entity.Shop;

import java.util.List;
import java.util.Optional;

@Repository
public interface ShopRepository extends JpaRepository<Shop, Integer> {
    
    // Tìm shop theo tài khoản chủ quán (Dành cho Vendor Dashboard)
    Optional<Shop> findByOwner(Account owner);

    List<Shop> findTop10ByStatusOrderByRatingDesc(String status);
    
    Page<Shop> findByShopNameContainingIgnoreCase(String shopName, Pageable pageable);
    
    long countByStatus(String status);
=======
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.tuan.entity.Shop;

import java.util.List;

@Repository
public interface ShopRepository extends JpaRepository<Shop, Integer> {
    // Lấy danh sách shop đang hoạt động
    List<Shop> findTop10ByStatusOrderByRatingDesc(String status);
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963
}