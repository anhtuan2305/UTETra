package vn.tuan.repository;

<<<<<<< HEAD
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
=======
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.tuan.entity.Account;

import java.util.Optional;

@Repository
public interface AccountRepository extends JpaRepository<Account, Integer> {
    Optional<Account> findByEmail(String email);
    boolean existsByEmail(String email);
<<<<<<< HEAD
    
    // Tìm kiếm tài khoản có phân trang
    Page<Account> findByEmailContainingIgnoreCase(String email, Pageable pageable);
    
    // Đếm số lượng theo role
    long countByRole(String role);
=======
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963
}