package vn.tuan.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.tuan.entity.Category;
import vn.tuan.entity.Product;
<<<<<<< HEAD
import vn.tuan.entity.Shop;
=======
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963

import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {
<<<<<<< HEAD

    // Lấy sản phẩm đang bán có phân trang
    Page<Product> findByStatus(String status, Pageable pageable);

    // Tìm kiếm theo tên
    Page<Product> findByNameContainingIgnoreCaseAndStatus(String name, String status, Pageable pageable);

    // Gợi ý món cùng loại
    List<Product> findTop4ByCategoryAndIdNotAndStatus(Category category, Integer id, String status);

    // Dành cho Vendor quản lý
    List<Product> findByShopOrderByCreatedAtDesc(Shop shop);

    // DÀNH CHO GUEST: Sản phẩm bán trên 10 đơn, sắp xếp theo lượt bán giảm dần
    Page<Product> findByStatusAndSoldCountGreaterThanOrderBySoldCountDesc(String status, int minSold, Pageable pageable);

    // DÀNH CHO USER: Lấy theo thứ tự tạo mới nhất
    Page<Product> findByStatusOrderByCreatedAtDesc(String status, Pageable pageable);
=======
    // Lấy danh sách sản phẩm theo trạng thái có phân trang
    Page<Product> findByStatus(String status, Pageable pageable);
    
    // Tìm kiếm sản phẩm theo tên
    Page<Product> findByNameContainingIgnoreCaseAndStatus(String name, String status, Pageable pageable);

    // Lấy top 4 sản phẩm cùng danh mục (gợi ý món tương tự)
    List<Product> findTop4ByCategoryAndIdNotAndStatus(Category category, Integer id, String status);
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963
}