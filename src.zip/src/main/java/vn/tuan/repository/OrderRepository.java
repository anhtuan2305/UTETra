package vn.tuan.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.tuan.entity.Account;
import vn.tuan.entity.Order;
<<<<<<< HEAD
import vn.tuan.entity.Shop;
=======
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963

import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Order, Integer> {
    List<Order> findByAccountOrderByCreatedAtDesc(Account account);
<<<<<<< HEAD
    
    // Shipper
    List<Order> findByStatusInOrderByCreatedAtDesc(List<String> statuses);
    
    // Vendor: Lấy danh sách đơn theo shop
    List<Order> findByShopOrderByCreatedAtDesc(Shop shop);

    long countByStatus(String status);
=======
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963
}