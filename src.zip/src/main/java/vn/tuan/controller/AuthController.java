package vn.tuan.controller;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import vn.tuan.dto.RegisterDTO;
import vn.tuan.service.AccountService;

@Controller
public class AuthController {

    @Autowired
    private AccountService accountService;

<<<<<<< HEAD
=======
    // Trang đăng nhập
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963
    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

<<<<<<< HEAD
=======
    // Trang đăng ký
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963
    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("registerDTO", new RegisterDTO());
        return "register";
    }

<<<<<<< HEAD
    @PostMapping("/register")
    public String handleRegister(@Valid @ModelAttribute("registerDTO") RegisterDTO registerDTO,
                                 BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) return "register";
=======
    // Xử lý gửi form đăng ký
    @PostMapping("/register")
    public String handleRegister(@Valid @ModelAttribute("registerDTO") RegisterDTO registerDTO,
                                 BindingResult bindingResult,
                                 Model model) {
        if (bindingResult.hasErrors()) {
            return "register";
        }
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963

        String result = accountService.register(registerDTO);
        if (!"SUCCESS".equals(result)) {
            model.addAttribute("errorMessage", result);
            return "register";
        }
<<<<<<< HEAD
        return "redirect:/verify-otp?email=" + registerDTO.getEmail();
    }

=======

        // Chuyển hướng sang trang nhập OTP kèm theo email
        return "redirect:/verify-otp?email=" + registerDTO.getEmail();
    }

    // Trang nhập mã OTP
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963
    @GetMapping("/verify-otp")
    public String showVerifyOtpForm(@RequestParam("email") String email, Model model) {
        model.addAttribute("email", email);
        return "verify-otp";
    }

<<<<<<< HEAD
    @PostMapping("/verify-otp")
    public String handleVerifyOtp(@RequestParam("email") String email,
                                  @RequestParam("otp") String otp, Model model) {
        if (accountService.verifyOtp(email, otp)) {
            model.addAttribute("successMessage", "Kích hoạt tài khoản thành công! Bạn có thể đăng nhập ngay.");
            return "login";
        }
=======
    // Xử lý xác thực OTP
    @PostMapping("/verify-otp")
    public String handleVerifyOtp(@RequestParam("email") String email,
                                  @RequestParam("otp") String otp,
                                  Model model) {
        boolean isVerified = accountService.verifyOtp(email, otp);
        if (isVerified) {
            model.addAttribute("successMessage", "Kích hoạt tài khoản thành công! Bạn có thể đăng nhập ngay.");
            return "login";
        }

>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963
        model.addAttribute("email", email);
        model.addAttribute("errorMessage", "Mã OTP không chính xác hoặc đã hết hạn!");
        return "verify-otp";
    }
<<<<<<< HEAD

    // ====== TÍNH NĂNG QUÊN MẬT KHẨU ======

    @GetMapping("/forgot-password")
    public String showForgotPasswordForm() {
        return "forgot-password";
    }

    @PostMapping("/forgot-password")
    public String handleForgotPassword(@RequestParam("email") String email, Model model) {
        String result = accountService.processForgotPassword(email);
        if ("SUCCESS".equals(result)) {
            return "redirect:/reset-password?email=" + email;
        }
        model.addAttribute("errorMessage", result);
        return "forgot-password";
    }

    @GetMapping("/reset-password")
    public String showResetPasswordForm(@RequestParam("email") String email, Model model) {
        model.addAttribute("email", email);
        return "reset-password";
    }

    @PostMapping("/reset-password")
    public String handleResetPassword(@RequestParam("email") String email,
                                      @RequestParam("otp") String otp,
                                      @RequestParam("newPassword") String newPassword,
                                      Model model) {
        if (accountService.resetPassword(email, otp, newPassword)) {
            model.addAttribute("successMessage", "Đổi mật khẩu thành công! Hãy đăng nhập lại.");
            return "login";
        }
        model.addAttribute("email", email);
        model.addAttribute("errorMessage", "Mã OTP sai hoặc đã hết hạn!");
        return "reset-password";
    }
=======
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963
}