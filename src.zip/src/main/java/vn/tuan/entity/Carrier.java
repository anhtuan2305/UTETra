package vn.tuan.entity;

import jakarta.persistence.*;
import lombok.*;
<<<<<<< HEAD

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "carriers")
=======
import java.math.BigDecimal;

@Entity
@Table(name = "Carriers")
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
<<<<<<< HEAD
=======
@Builder
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963
public class Carrier {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

<<<<<<< HEAD
    // Map cột name
    @Column(name = "name", length = 100)
    private String name;

    // Map thêm cột carrier_name để thỏa mãn cả 2 cột NOT NULL trong DB
    @Column(name = "carrier_name", length = 100)
    private String carrierName;

    @Column(name = "base_fee", precision = 18, scale = 2)
    private BigDecimal baseFee;

    @Column(name = "is_active")
    private Boolean isActive = true;

    @Column(name = "created_at")
    private LocalDateTime createdAt = LocalDateTime.now();

    public Carrier(String name, BigDecimal baseFee, Boolean isActive) {
        this.name = name;
        this.carrierName = name; // Đồng bộ cả 2 trường cùng giá trị
        this.baseFee = baseFee;
        this.isActive = isActive;
        this.createdAt = LocalDateTime.now();
    }
=======
    @Column(nullable = false, length = 100)
    private String name; // Giao Hàng Nhanh, Shopee Xpress...

    @Column(name = "base_fee", precision = 10, scale = 2)
    private BigDecimal baseFee;
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963
}