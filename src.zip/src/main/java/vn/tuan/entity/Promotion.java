package vn.tuan.entity;

import jakarta.persistence.*;
import lombok.*;
<<<<<<< HEAD

=======
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
<<<<<<< HEAD
@Table(name = "promotions")
=======
@Table(name = "Promotions")
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
<<<<<<< HEAD
=======
@Builder
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963
public class Promotion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

<<<<<<< HEAD
    @Column(nullable = false, unique = true, length = 50)
    private String code;

    @Column(nullable = false)
    private Integer discountPercent;

    @Column(precision = 18, scale = 2)
    private BigDecimal maxDiscount;

    @Column(precision = 18, scale = 2)
    private BigDecimal minOrderAmount;

    private Boolean isActive = true;

    private LocalDateTime createdAt = LocalDateTime.now();

    public Promotion(String code, Integer discountPercent, BigDecimal maxDiscount, BigDecimal minOrderAmount, Boolean isActive) {
        this.code = code;
        this.discountPercent = discountPercent;
        this.maxDiscount = maxDiscount;
        this.minOrderAmount = minOrderAmount;
        this.isActive = isActive;
        this.createdAt = LocalDateTime.now();
    }
=======
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "shop_id") // Nếu null thì là mã sàn của Admin, có ID là mã riêng của Shop
    private Shop shop;

    @Column(nullable = false, unique = true, length = 50)
    private String code;

    @Column(name = "discount_percent")
    private Integer discountPercent;

    @Column(name = "max_discount", precision = 10, scale = 2)
    private BigDecimal maxDiscount;

    @Column(name = "start_date")
    private LocalDateTime startDate;

    @Column(name = "end_date")
    private LocalDateTime endDate;

    @Column(name = "usage_limit")
    private Integer usageLimit;
>>>>>>> b3ddb13cf6d0325d0377d21f5f20532c12641963
}